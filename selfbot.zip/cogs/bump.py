import discord
from discord.ext import commands

APPLICATION_ID = "302050872383242240"
COMMAND_ID = "947088344167366698"
COMMAND_VERSION = "1051151064008769576"
KINOEMON_ID = 738981216451297310

class Bump(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    def create_interaction_payload(self, channel_id, guild_id):
        return {
            "type": 2,
            "application_id": APPLICATION_ID,
            "guild_id": str(guild_id),
            "channel_id": str(channel_id),
            "session_id": "selfbot-session-id",
            "data": {
                "version": COMMAND_VERSION,
                "id": COMMAND_ID,
                "name": "bump",
                "type": 1,
                "application_command": {
                    "id": COMMAND_ID,
                    "application_id": APPLICATION_ID,
                    "version": COMMAND_VERSION,
                    "default_member_permissions": None,
                    "type": 1,
                    "name": "bump",
                    "description": "Pushes your server to the top of all your server's tags and the front page",
                    "dm_permission": True,
                    "contexts": None,
                    "integration_types": [0],
                    "nsfw": False,
                },
            },
        }

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if (
            message.author.id == KINOEMON_ID
            and message.embeds
            and message.embeds[0].title == "BUMP通知"
            and message.embeds[0].description == "BUMPのお時間になりました。"
        ):
            payload = self.create_interaction_payload(
                message.channel.id, message.guild.id
            )

            try:
                await self.bot.http.request(
                    discord.http.Route("POST", "/interactions"), json=payload
                )
                print("実行しました")
            except Exception as e:
                print(f"実行に失敗しました：{e}")

async def setup(bot):
    await bot.add_cog(Bump(bot))